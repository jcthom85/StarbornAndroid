# NPCs — World 4: The Foundry

## Major Characters

### Commander Rylos (The Villain)
*   **Role:** The "Father" of the Phantom Project.
*   **Chain of command:** Answers to Orbital Compliance (Lt. Arden Vale).
*   **Location:** The Core (Boss Arena).
*   **Appearance:** Cybernetically enhanced soldier. Half his face is chrome. He speaks without moving his mouth.
*   **Personality:** Possessive. He doesn't hate Gh0st; he is *disappointed* in him.
*   **Key Line:** "You are malfunctioning, Unit 734. Submit for correction. Pain is just data leaving the body."
*   **Fate:** Defeated by the party. Executed by Vale via remote kill-switch (demonstrating Vale's ruthlessness).

### Gh0st (The Prodigal Son)
*   **Role:** Party Member Focus.
*   **State of Mind:** **Determined.** The glitched confusion of World 2 is gone. He is angry.
*   **Bark:** "I know where the vents are. I crawled through them when I was small."

### Lt. Arden Vale (The Voice)
*   **Role:** The New Boss.
*   **Location:** Hologram / Comms.
*   **Function:** Stinger Reveal.
*   **Key Line:** "Director Thorne's metrics are... inefficient. We are initiating a reboot. Goodbye, Commander."

## Hostiles

### Magma Drone
*   **Role:** Aerial Harasser.
*   **Appearance:** Drone coated in heat-shielding ceramics.
*   **Attack:** Napalm spray.

### Slag Golem
*   **Role:** Heavy Tank.
*   **Appearance:** A semi-sentient blob of molten rock held together by a magnetic core.
*   **Weakness:** **Ice/Water** (Cooling Springs water?) or **Blast Wave** (Shatter).