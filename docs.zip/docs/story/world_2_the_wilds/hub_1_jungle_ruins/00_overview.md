# World 2: The Wilds — Hub 1: Jungle Ruins

## Overview
Sector 9. A forbidden zone on the planet surface where the terraforming failed—or worked too well. It's a bioluminescent jungle claiming ancient stone ruins.

## Key Themes
- **Survival:** Nova and Zeke are out of their element.
- **The Past:** Discovering the history of the Architects and the Aethel.
- **Assembly:** Gathering the full party (Orion, Gh0st).
- **The Signal:** The beacon that pulled them here.
- **Breathers:** Moments of open sky and calm water (Canopy Ridge, Tideglass Beach) to let the crew feel like people, not just fugitives.

## Transition Points
- **From Mines:** Via the Crash Interlude.
- **To Spire:** Via *The Astra* (Repaired Ship).
