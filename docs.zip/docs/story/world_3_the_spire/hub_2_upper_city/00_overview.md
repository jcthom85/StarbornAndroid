# World 3: The Spire — Hub 2: Upper City

## Overview
The "Cloud District" of the Spire. Clean, white, gold, and sterile. This is where the Dominion executives live. It feels like a hospital mixed with a luxury hotel.

## Key Themes
- **Wealth Disparity:** Contrast with the slums.
- **The Heist:** Ocean's Eleven style infiltration.
- **The Relic:** Finding the second Relic (The Lens).
- **False Paradise (Breather):** A rooftop Skypark garden where the air is clean, the sun is fake, and the utopia is a costume.

## Transition Points
- **To World 4:** Via *The Astra* (Deep-Core Engine hunt).
