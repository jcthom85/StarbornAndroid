# NPCs — World 3, Hub 2: Upper City

## Major Characters

### The Administrator (Boss)
*   **Role:** Dominion Regional Manager.
*   **Location:** The Landing Pad (MQ_16).
*   **Appearance:** Tailored suit that integrates with a combat exoskeleton.
*   **Personality:** Condescending, annoyed rather than angry. Views the heist as an "audit failure."
*   **Key Line:** "Do you know how much the glass you just broke costs? Deducting it from your bounty."

### VIP Guest (Obstacle)
*   **Role:** Stealth mechanics.
*   **Appearance:** Avant-garde fashion, drinking champagne.
*   **Behavior:** If they see you, they don't attack; they scream "Security!" (Alert Level +1).
*   **Bark:** "Ugh, a worker? Up here? Someone call maintenance."

## Party Members (Heist Roles)

### Nova (The Face/Wildcard)
*   **Role:** Improviser.
*   **State of Mind:** **Cocky.** She thinks she's Robin Hood. This confidence will bite her when the alarm trips.

### Zeke (The Hacker)
*   **Role:** Tech Support.
*   **Location:** Laundry Node (Disabling sensors).
*   **Bark:** "I hate their firewalls. They're so... smug."

### Gh0st (The Muscle)
*   **Role:** Security Detail (Disguised).
*   **Bark:** "This suit restricts movement by 12%. Unacceptable."