# World 3: The Spire — Hub 1: Lower City (The Return)

## Overview
The "Spire" is a massive vertical city. The Lower City is the foundation—rain-slicked, neon-lit poverty where the workers live. It is surveillance-heavy but chaotic.

## Key Themes
- **The Blockade:** The party has a ship (*The Astra*), but cannot leave the planet due to the **Dominion Planetary Shield**.
- **Anonymity:** Nova is a fugitive here. She must blend in.
- **The Insider:** Zeke returns home to find his life erased.
- **Breather:** A loud, colorful Night Market where the Lower City feels alive (not just oppressed).

## Transition Points
- **To Upper City:** Restricted elevator access (The primary goal of this Hub).
- **From Wilds:** Arrival point via Sewer/Smuggler route.
