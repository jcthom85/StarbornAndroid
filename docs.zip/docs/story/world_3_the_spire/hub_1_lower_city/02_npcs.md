# NPCs — World 3, Hub 1: Lower City

## Allies

### Jax (The Bartender)
*   **Role:** Information Broker / Shopkeeper.
*   **Location:** The Static.
*   **Appearance:** One arm is a heavy-duty cybernetic loader claw. Wears a dirty apron over a flight suit.
*   **Personality:** Gruff, tired, loyal to credits but hates the "Suits" upstairs.
*   **Key Line:** "Don't ask what's in the drink. Don't ask who was sitting there yesterday. Rules of the house."

### Mika (The Heart)
*   **Role:** Street Vendor (Quest Giver).
*   **Location:** Night Market Alley.
*   **Appearance:** Teenager with neon hair and a respirator mask around her neck.
*   **Personality:** Optimistic despite the rain. Represents the "normal people" Nova is saving.
*   **Key Line:** "Try the skewers! Real protein today, I promise. No recycled paste."

### Zeke (The Return)
*   **Role:** Party Member.
*   **State of Mind:** **Haunted.** This was his home, and now he's a ghost here. He sees his old life erased.
*   **Bark:** "They reformatted my drive... I mean, my apartment. They threw out my plants."

## Hostiles

### Riot Guard (Mob)
*   **Role:** Enforcer.
*   **Appearance:** Faceless helmet, stun-baton, heavy riot shield.
*   **Behavior:** Blocks paths. Demands ID.
*   **Bark:** "Citizen, halt. Scan in progress."

### Sentinel Mk. I (Mini-Boss)
*   **Role:** Automated Defense.
*   **Appearance:** Tripod combat droid with a rotating Gatling arm.
*   **Mechanic:** Stationary turret mode vs. Mobile chase mode.