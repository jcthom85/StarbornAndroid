# Events — World 1: The Mines

## EVT_W1_01: The Discovery
*   **Trigger:** Nova enters the Ancient Chamber and interacts with the "Humming Shard."
*   **Visuals:**
    *   The chamber isn’t carved like the rest of the mine—its angles are too clean, too intentional. Dominion didn’t build this. They found it.
    *   Nova touches the Relic. It’s not a beep. It’s a **pressure**.
    *   The air in the room drops ten degrees. The sound of the mine (drills, vents) vanishes, replaced by a hum that she feels in her teeth before she hears it.
    *   It starts as a headache (dissonance). It snaps into a terrifying, perfect clarity (harmony).
    *   **The Sensation:** The universe didn't boot up. It just stopped holding its breath. For the first time, Nova wasn't just standing in the room; she *was* the room. She was the rock, the air, and the relic.
    *   Then the connection snaps.
    *   Somewhere far above, a Dominion sensor reads the spike and quietly screams.
    *   Screen flashes white. Nova wakes up on the floor of the chamber holding the **Echo Relic**, shivering, with a nosebleed.
    *   She tries to stand. Her head splits like a pressurized hull losing containment. For a beat, even Jed’s name won’t come—then it snaps back.
    *   **Nova (Internal):** The silence is fake. The noise is real.
*   **Gameplay Result:** Unlocks **"Blast"** (Basic Ranged Attack).

## EVT_W1_02: The Lockdown
*   **Trigger:** Returning to Homestead Hub after finding the Relic.
*   **Visuals:**
    *   All lights in the Hub turn RED.
    *   Sirens blare.
    *   Giant holographic screens descend.
    *   **The Warden (On Screen):** "Security Breach in Sector 4. Biological contaminant detected. Initiate containment protocol. Purge all organic assets."
*   **Gameplay Result:** Hub becomes a hostile zone. Guards spawn in Trade Row.

## EVT_W1_03: The Sacrifice
*   **Trigger:** Reaching the Cargo Lift at the end of Maintenance Tunnels.
*   **Visuals:**
    *   Nova and Jed reach the lift.
    *   Warden's Enforcers (Elites) breach the door behind them.
    *   The Lift controls are jammed. Jed runs *back* to the manual override panel on the wall.
    *   **Jed:** "Get out of here, Nova! Find the sky!"
    *   Jed presses a humming Chime into Nova's hand. "Found it in scrap. Dominion called it a Ghost Signal Cell. If you find a ship, this wakes it."
    *   Jed smashes the panel. The lift door slams shut between them.
    *   Through the window, Nova sees Jed charge the Enforcers with his wrench as the lift rockets upward.
*   **Gameplay Result:** Launch Bay access opens. The escape continues.
