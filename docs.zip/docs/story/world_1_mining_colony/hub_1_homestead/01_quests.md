# Quests — World 1: The Mines (Hub 1: Homestead)

## Main Questline (The Origin)

| ID | Title | Objective | Key Steps | Rewards | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **MQ_01** | **Wake Up Call** | Report to Jed. | 1. Wake up in Nova's Bunk.<br>2. Interact with objects (Tutorial).<br>3. Talk to Jed at the Workshop. | 50 Credits | Basics Tutorial. **Note:** Nova wakes up with a splitting migraine. The credits are for painkillers. |
| **MQ_02** | **Paperwork** | Get Mine Access. | 1. Gate Guard denies entry (Shift is full).<br>2. Hacking Minigame (Fail state leads to finding a back route).<br>3. Reach Admin Window.<br>4. **Meet Zeke.** He spots Nova's anomaly readings. **Zeke is already under internal review; he gives her the pass to bury the data trail, inadvertently binding his fate to hers.** | Mining Pass | **Zeke Introduced.** |
| **MQ_03** | **The Echo** | Find the source. | 1. Enter Stellarium Mine.<br>2. Navigate to Deep Sector 4.<br>3. Find the **Tuning Fork** (Relic).<br>4. **Unlock Source Art: Blast Wave (Nova).** | **Relic: Tuning Fork** | First Source Art. |
| **MQ_04** | **Red Alert** | Escape the Mines. | 1. Lockdown triggers.<br>2. Zeke guides Nova via comms ("They're coming! Go left!").<br>3. Nova fights back to the Hub using Blast Wave. | None | Combat Tutorial. |
| **MQ_05** | **The Launch** | Escape the Colony. | 1. Defend Jed's Workshop from Security.<br>2. Jed hands Nova the **Chime** and sacrifices himself.<br>3. Nova and Zeke board the Ore Pod.<br>4. **Boss: The Warden.**<br>5. Launch sequence initiated. | **Zeke Joins Party**<br>**Unlock Source Art: Disruptor (Zeke)** | Zeke touches the Relic on the ship (Catch-Up). |

## Side Quests (Hub 1)

These quests reward specific Combat Skills, encouraging players to explore before the point of no return.

| ID | Title | Quest Giver | Objective | Rewards | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **SQ_01** | **The Scavenger's Stash** | Scrapper (Fence) | Locate a hidden cache of old mining explosives in the vents. | **Nova Skill: Pulse Grenade** | Teaches usage of consumables/AoE. |
| **SQ_02** | **System Flush** | Doc (Medic) | Clear out chemical slimes clogging the clinic's ventilation. | **Zeke Skill: Corrosive Knuckles** | Explains Damage-over-Time (Acid) mechanics. |
| **SQ_03** | **Heavy Lifting** | Foreman Bogs | Use a loader mech to clear debris (Mini-game). | **Nova Skill: Slide Kick** | Teaches Guard Breaking / Stagger. |
