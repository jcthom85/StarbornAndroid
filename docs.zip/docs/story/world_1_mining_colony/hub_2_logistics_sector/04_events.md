# Events — World 1, Hub 2: Logistics Sector

## EVT_W1_04: The Meeting
*   **Trigger:** MQ_02 (Approaching Window 4).
*   **Action:**
    *   **Zeke:** "Name? ID? Clearance Score?"
    *   **Nova:** "Uh... Nova. Mining Unit 7."
    *   Zeke looks up. His eyes widen. He taps his screen furiously.
    *   **Zeke:** "Unit 7... Deceased. Accident reported 4 hours ago. Interesting."
    *   **Nova:** "I'm not dead."
    *   **Zeke:** "According to this, you are. But I like ghosts. Here's your pass. Go make some trouble."

## EVT_W1_05: The Escape
*   **Trigger:** MQ_05 (Launch Bay).
*   **Action:**
    *   The Warden crashes through the ceiling.
    *   **Warden:** "Asset Forfeiture In Progress."
    *   **Zeke:** "I hacked the pod! I spliced Jed's Ghost Signal Cell into the core. It's the only way it clears the rail!"
    *   Nova and Zeke jump into the pod.
    *   The Pod shoots up the rail.
    *   **Console:** "AUTO-NAV: UNKNOWN SIGNAL LOCK."
    *   **Zeke:** "I can't override it!"
    *   The Planetary Shield blooms—solid outside the corridor. Impact. The pod spirals toward Sector 9.
    *   Fade to Black.
