# Quests — World 1: The Mines (Hub 2: Logistics & Deep Mine)

## Main Questline (The Defection)

| ID | Title | Objective | Key Steps | Rewards | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **MQ_03** | **Into the Dark** | Descend to Sector 4. | 1. Use the **Sector 4 Pass** at the Deep Elevator.<br>2. Navigate the **Old Tunnels** (Combat: Rock-Borers & Drones).<br>3. Reach the **Echo Chamber**.<br>4. Interact with the **Tuning Fork** (Relic). | **Source Art: Blast Wave (Nova)** | The "Dungeon" phase. |
| **MQ_04** | **Red Alert** | Escape the Purge. | 1. The Relic trips the alarm. **The Warden** locks down the sector.<br>2. Fight back up the elevator (Wave Defense).<br>3. Zeke overrides the blast doors to let you into the Logistics Hub. | None | Chase Sequence. |
| **MQ_05** | **The Launch** | Hijack a Pod. | 1. Fight through **Security Checkpoint B** (Human Guards).<br>2. Reach the **Launch Bay**.<br>3. **Boss: The Warden.** (Weak to Blast Wave).<br>4. Zeke splices the **Chime** into the pod. Launch. | **Zeke Joins Party**<br>**Source Art: Disruptor (Zeke)** | Transition to World 2. |

## Side Quests

| ID | Title | Quest Giver | Objective | Rewards | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **SQ_04** | **Protocol Override** | Hacked Terminal (Server Room) | Upload a virus to the security grid to lower turret defenses. | **Passive Skill: Tech Savvy** (Hacking Speed Up) | Encourages exploration of side rooms. |
| **SQ_05** | **The Lost Shift** | Datapad (Deep Mine) | Find the ID tags of 3 miners lost in a cave-in. | **Weapon Mod: Recoil Dampener** | Lore: Shows Dominion negligence. |
